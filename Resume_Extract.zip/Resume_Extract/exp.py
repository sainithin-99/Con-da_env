import tiktoken
from langchain_community.document_loaders import UnstructuredFileLoader
from langchain_community.document_loaders import UnstructuredPDFLoader
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import Chroma
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_huggingface import HuggingFaceEndpoint
#from langchain import PromptTemplate
from langchain.prompts import ChatPromptTemplate
import chromadb
from langchain.chains import RetrievalQA
from datetime import datetime
from langchain_openai.chat_models import ChatOpenAI
import pprint
from langchain_openai import OpenAIEmbeddings
import langchain_core
import pytesseract
from sklearn.metrics.pairwise import cosine_similarity

import os
hf_token ="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"

os.environ["HUGGINGFACEHUB_API_TOKEN"]= hf_token

class Document:
    def __init__(self, text, metadata={}):
        self.page_content = text
        self.metadata = metadata

        
import fitz
def load_file(filepath):
    text = ''
    with fitz.open(filepath) as pdf_document:
        for page_num in range(pdf_document.page_count):
            page = pdf_document.load_page(page_num)
            text += page.get_text()
    return text

def Scores(documents,jd):
    job_desc_prompt = f"""
You are an expert in talent acquisition. Given the following job description, score each resume on a scale of 100. The scores should be divided into the following sections: skills (20%), projects (40%), work experience (30%), and education (10%). Projects should have the highest weightage. Provide a score for each section, the total score, and the reason for each score.

Job Description: {jd}

Please evaluate the following resumes:
"""

    resume_prompt = job_desc_prompt + f"\nResume:\n{documents}\n\nScore (out of 100):\n"


    print(resume_prompt)

    # prompt_template = langchain_core.prompts.PromptTemplate(input_variables=["documents" , "jd" ],template=resume_prompt)
    
    # repo_id="mistralai/Mistral-7B-Instruct-v0.3"
    # #repo_id="meta-llama/Meta-Llama-3-8B-Instruct"
    # llm=HuggingFaceEndpoint(repo_id=repo_id,temperature=0.7)
    # chain = prompt_template | llm

    # scores = chain.invoke(documents , jd)
    scores = 1
    return scores


def vectorstore(documents,jd):
    #jinaai/jina-embeddings-v2-small-en  
    embeddings = HuggingFaceEmbeddings(model_name="jinaai/jina-embeddings-v2-small-en",
                                        model_kwargs={'device': 'cpu','trust_remote_code':True})

    current_time = datetime.now()
    formatted_time = current_time.strftime("%Y-%m-%d%H%M%S")
    print("Current Time:", formatted_time)
    collection_name=formatted_time #need to give a unique name in the future this is done to avoid the retrieval of previous instance pdfs
    
    vectordb = Chroma.from_documents(documents, embeddings,collection_name=collection_name)

    endtime = datetime.now()
    end_time = endtime.strftime("%Y-%m-%d-%H:%M:%S")
    print("Current Time:", end_time)

    job_description = jd
    
    question ="You are an expert in talent acquisition that helps determine the best candidate among multiple suitable resumes.Use the following pieces of context to determine the best resume given a job description.Job description:\n"+job_description+"\nBased on the given job description"

    #query = question + "give an overall score for the resumes which is good fit to the job based on skills,education and work experience mentioned in it?"
    query = question + "give an overall score for the resumes which is good fit to the Full Stack Data Scientist role and good fit based on skills?"
    # query = question + "short list resumes which is good fit to the job based on skills,education and work experience mentioned in it?"+warning

    #retriever = vectordb.as_retriever()
    retriever = vectordb.as_retriever(search_kwargs={"k": 8})
    docs_retrieved=retriever.invoke(query)

    # job_description_embedding = embeddings.embed_documents([job_description])[0]
    # resume_embeddings = embeddings.embed_documents([doc.page_content for doc in documents])
    
    # # Calculate cosine similarities
    # similarities = cosine_similarity([job_description_embedding], resume_embeddings)[0]
    
    # # Print the similarities
    # for idx, (doc, similarity) in enumerate(zip(documents, similarities)):
    #     print(f"Resume {idx + 1} (Similarity: {similarity:.4f}):\n{doc.page_content[:100]}...\n")

    #print(docs_retrieved[0].page_content)
    for doc in docs_retrieved:
        print(doc.metadata)
    #print(result["source_documents"][0].metadata)

def main():
    resumes=["data\S_Aajin Roy.pdf",
            "data\S_Adarsh.pdf",
            "data\S_Akhil_Rajan_Resume.pdf",
            "data\S_midhun.pdf",
            r"data\Arvind Kumar Jangid.pdf",
            r"data\Chandrajeet PratapSingh.pdf",
            r"data\S_DEEPAMERLINDIXONK.pdf",
            r"data\Jeevan Dhadge.pdf",
            r"data\KUNALTAJANE.pdf",
            r"data\S_Parag Kumar Jain.pdf",
            r"data\Ramandeep Bains.pdf",
            r"data\S_Rohit Kumar Gupta.pdf",
            r"data\S_Shephali Gupta.pdf"
            ]
    documents=[]

    jd=load_file(r"C:\Users\polam\OneDrive\Desktop\Study\Allianz\HR POC\Resume scanner\data\Full-stack Data Scientist_Job Description_v2.docx")

    docs=load_file(resumes[0])
    #document = Document(docs, metadata={"filename":os.path.basename(resume)})
    S = Scores(docs,jd)
    print(S)
    #documents.append(document)

    # for resume in resumes:
    #     docs=load_file(resume)
    #     document = Document(docs, metadata={"filename":os.path.basename(resume)})
    #     S = Scores(docs,jd)
    #     print(S)
    #     documents.append(document)
    
    #vectorstore(documents,jd)
    


if __name__ == "__main__":
    main()  